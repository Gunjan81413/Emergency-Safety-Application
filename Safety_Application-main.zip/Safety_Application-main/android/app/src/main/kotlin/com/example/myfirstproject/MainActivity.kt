package com.example.myfirstproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
